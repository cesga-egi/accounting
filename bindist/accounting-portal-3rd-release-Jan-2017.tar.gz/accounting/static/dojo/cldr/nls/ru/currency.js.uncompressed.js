define(
"dojo/cldr/nls/ru/currency", //begin v1.x content
{
	"HKD_displayName": "Гонконгский доллар",
	"CHF_displayName": "Швейцарский франк",
	"JPY_symbol": "¥",
	"CAD_displayName": "Канадский доллар",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Юань Ренминби",
	"USD_symbol": "$",
	"AUD_displayName": "Австралийский доллар",
	"JPY_displayName": "Японская иена",
	"CAD_symbol": "CA$",
	"USD_displayName": "Доллар США",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Английский фунт стерлингов",
	"GBP_symbol": "£",
	"AUD_symbol": "A$",
	"EUR_displayName": "Евро"
}
//end v1.x content
);